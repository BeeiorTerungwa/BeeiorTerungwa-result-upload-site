# Student Result Upload Site

A small browser-based site for uploading student results and checking them by matric number.
Built with HTML, CSS and JavaScript (no frameworks, no server).

## What it does
- Upload a result: student name, matric number (format 23/095244109), course code (e.g. CSC301) and score (0-100).
- Validates every field and shows an error under the field that is wrong.
- Rejects a second result for the same matric number and course.
- Works out the letter grade (A 70+, B 60-69, C 50-59, D 45-49, E 40-44, F below 40).
- Check a result: enter a matric number to see that student's results and average score.
- Remove one result, or clear all. Results are kept in the browser (localStorage) between visits.

## Folder structure
```
result-upload-site/
  README.md
  package.json
  src/
    index.html   page structure
    style.css    layout, light and dark themes, small-screen styles
    logic.js     validation, grading, search and average (no DOM code)
    script.js    form handling, page updates and browser storage
  tests/logic.test.js   12 automated tests for logic.js
```

## How to run
Open `src/index.html` in any modern browser. No installation is needed.

## How to run the tests
Requires Node.js 18 or newer: `npm test`

## Limitations
No login, no database and no file upload. Results are stored only in the browser used.
