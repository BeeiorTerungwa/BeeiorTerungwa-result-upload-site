const test = require('node:test');
const assert = require('node:assert');
const { gradeFor, validateResult, buildResult, findByMatric, averageScore } = require('../src/logic.js');

const good = { name: 'Okon Mary', matric: '23/095244001', course: 'csc301', score: '72' };

test('T01 grade boundaries', () => {
  assert.deepStrictEqual([100, 70, 69, 60, 50, 45, 40, 39, 0].map(gradeFor), ['A','A','B','B','C','D','E','F','F']);
});
test('T02 valid entry has no errors', () => assert.deepStrictEqual(validateResult(good, []), {}));
test('T03 empty entry reports four errors', () => assert.strictEqual(Object.keys(validateResult({}, [])).length, 4));
test('T04 short name rejected', () => assert.ok(validateResult({ ...good, name: 'Al' }, []).name));
test('T05 bad matric format rejected', () => assert.ok(validateResult({ ...good, matric: '23-095244001' }, []).matric));
test('T06 bad course code rejected', () => assert.ok(validateResult({ ...good, course: 'CS30' }, []).course));
test('T07 score above 100 rejected', () => assert.ok(validateResult({ ...good, score: '101' }, []).score));
test('T08 non-numeric and decimal scores rejected', () => {
  assert.ok(validateResult({ ...good, score: 'abc' }, []).score);
  assert.ok(validateResult({ ...good, score: '55.5' }, []).score);
});
test('T09 duplicate matric and course rejected', () => {
  const saved = [buildResult(good)];
  assert.ok(validateResult(good, saved).course);
  assert.deepStrictEqual(validateResult({ ...good, course: 'CSC302' }, saved), {});
});
test('T10 buildResult trims, upper-cases and grades', () => {
  assert.deepStrictEqual(buildResult({ ...good, name: '  Okon Mary ' }),
    { name: 'Okon Mary', matric: '23/095244001', course: 'CSC301', score: 72, grade: 'A' });
});
test('T11 findByMatric returns only that student', () => {
  const list = [buildResult(good), buildResult({ ...good, matric: '23/095244002' })];
  assert.strictEqual(findByMatric(list, ' 23/095244001 ').length, 1);
  assert.strictEqual(findByMatric(list, '23/000000000').length, 0);
});
test('T12 averageScore', () => {
  assert.strictEqual(averageScore([]), 0);
  assert.strictEqual(averageScore([{ score: 70 }, { score: 55 }]), 62.5);
});
